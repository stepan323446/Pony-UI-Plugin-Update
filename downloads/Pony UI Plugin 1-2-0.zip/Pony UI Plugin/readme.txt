(RUS)
Pony UI Plugin был создан блогером Mariana Ponyriama для облегченния игрового процесса и изменения UI интерфейса.
https://www.youtube.com/channel/UC-X7_-qML3aXqrDQ2UKLFkA

Какие-либо данные не отправляются на сторонние сервера. За снижение производительности я не несу ответственность, но отмечу, что на моём ПК работает всё стабильно без просидания производительности.

Плагин изменяет исключительно визуальную оболочку, дополняя визуальным функционалом, не затрагивая саму игру.


(ENG)
Pony UI Plugin was created by blogger Mariana Ponyriama to facilitate gameplay and change the UI.
https://www.youtube.com/channel/UC-X7_-qML3aXqrDQ2UKLFkA

No data is sent to third party servers. I am not responsible for the decrease in performance, but I note that everything works stably on my PC without sluggish performance.

The plugin changes only the visual shell, adding visual functionality without affecting the game itself.